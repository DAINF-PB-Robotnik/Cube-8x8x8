#ifndef Cube_h
#define Cube_h

#include "Arduino.h"

class Cube
{
  public:
    Cube(int _RCLK_Pin, int _SRCLK_Pin, int _SER_Pin, int t1, int t2, int t3, int t4, int t5, int t6, int t7, int t8);
    void begin();
    void turnOn();
    void turnOff();
    void scanAnimation();
    void rainAnimation();
    void expandAnimation(int delayTime);

  private:
    int layer1;
    int layer2;
    int layer3;
    int layer4;
    int layer5;
    int layer6;
    int layer7;
    int layer8;
    int RCLK_Pin;
    int SRCLK_Pin;
    int SER_Pin;
    
    bool registers[];
    int layersArray[];

    void clearLayers();
    void lightAllLayers();
    void clearRegisters();
    void lightAllRegisters();
    void writeRegister();
    void setRegisterPin(int index, int value);

    void CubeExpanding(int topLayer, int botLayer,int supEsq, int supDir, int infEsq, int infDir, int delayTime);
    void CubeShrinking(int topLayer, int botLayer,int supEsq, int supDir, int infEsq, int infDir, int delayTime);

    void backToFront(int startingPoint);
    void frontToBack(int startingPoint);
    void rightToLeft(int startingPoint);
    void leftToRight(int startingPoint);
    void topToBot();
    void botToTop();
};

#endif