#include "Cube.h"
#include "Arduino.h"

#define numOfRegisterPins 64
#define numOfRainDrops 3

Cube::Cube(int _RCLK_Pin, int _SRCLK_Pin, int _SER_Pin, int t1, int t2, int t3, int t4, int t5, int t6, int t7, int t8){
    layer1 = t1;
    layer2 = t2;
    layer3 = t3;
    layer4 = t4;
    layer5 = t5;
    layer6 = t6;
    layer7 = t7;
    layer8 = t8;
    
    SER_Pin = _SER_Pin;   
    RCLK_Pin = _RCLK_Pin;  
    SRCLK_Pin = _SRCLK_Pin;
    
    registers[numOfRegisterPins];

    layersArray[0] = t1;
    layersArray[1] = t2;
    layersArray[2] = t3;
    layersArray[3] = t4;
    layersArray[4] = t5;
    layersArray[5] = t6;
    layersArray[6] = t7;
    layersArray[7] = t8;
}

void Cube::begin(){
    //Pinos de configuração
    pinMode(SER_Pin, OUTPUT);
    pinMode(RCLK_Pin, OUTPUT);
    pinMode(SRCLK_Pin, OUTPUT);

    //Pinos de camadas
    pinMode(layer1, OUTPUT);
    pinMode(layer2, OUTPUT);
    pinMode(layer3, OUTPUT);
    pinMode(layer4, OUTPUT);
    pinMode(layer5, OUTPUT);
    pinMode(layer6, OUTPUT);
    pinMode(layer7, OUTPUT);
    pinMode(layer8, OUTPUT);

    //Resetando as camadas e colunas
    clearLayers();
    clearRegisters();
    writeRegister();
}

//Errado--------------------------------
void Cube::clearLayers(){
    for(int i = 0; i < 8; i++){
        digitalWrite(layersArray[i], LOW);
    }
}

void Cube::lightAllLayers(){
  for(int i = 0; i < 8; i++){
     digitalWrite(layersArray[i], HIGH);
  }
}

void Cube::clearRegisters(){
    for(int i = numOfRegisterPins - 1; i >=  0; i--){
        registers[i] = LOW;
    }
}

void Cube::lightAllRegisters(){
    for(int i = numOfRegisterPins - 1; i >=  0; i--){
        registers[i] = HIGH;
    }
}

void Cube::writeRegister(){
    digitalWrite(RCLK_Pin, LOW);

    for(int i = numOfRegisterPins - 1; i >=  0; i--){
        digitalWrite(SRCLK_Pin, LOW);

        int val = registers[i];

        digitalWrite(SER_Pin, val);
        digitalWrite(SRCLK_Pin, HIGH);

    }
    
    digitalWrite(RCLK_Pin, HIGH);    
}

void Cube::setRegisterPin(int index, int value){
    registers[index] = value;
}

// Animations interface
//Desliga todos os leds
void Cube::turnOff(){
    clearRegisters();
    writeRegister();
    clearLayers();  
}

//Ligas todos os leds ----------------------------------------------->
void Cube::turnOn(){
    lightAllRegisters();
    writeRegister();
    lightAllLayers(); 
}

//Reproduz a animação de scanner, direçoes aleatórias
void Cube::scanAnimation(){
    int side = random(0,7);

    switch (side) {
        case 1:
            frontToBack(0);
            break;
        case 2:
            backToFront(56);
            break;
        case 3:
            topToBot();
            break;
        case 4:
            botToTop();
            break;
        case 5:
            leftToRight(0);
            break;
        case 6:
            rightToLeft(7);
            break;
        default:
            // statements
            break;
    }
    clearRegisters();
    writeRegister();
    clearLayers();
}

//Reproduz a animação de chuva com 3 colunas de leds simultaneamente
void Cube::rainAnimation(){ 
    int columns[numOfRainDrops];
    for(int i = 0; i < numOfRainDrops; i++){
        columns[i] = random(0,64);       
    }

    for(int i = 0; i < numOfRainDrops; i++){
        setRegisterPin(columns[i], HIGH);
    }
    writeRegister();

    for(int i = layer8; i >= layer1 - 1; i--){
        digitalWrite(i, HIGH);
        digitalWrite(i + 1, LOW);
        digitalWrite(i - 1, LOW);        
        delay(50);
    }

    for(int i = 0; i < numOfRainDrops; i++){
        setRegisterPin(columns[i], LOW);
    }
    writeRegister();
}

//Reproduz a animação de cubo expandindo e contraindo com um determinado intervalo
void Cube::expandAnimation(int delayTime){
    CubeExpanding(layer5, layer4, 36, 35, 28, 27, delayTime);
    delay(delayTime);
    CubeShrinking(layer8, layer1,63,56,7,0, delayTime);
}

//Funções auxiliares da animação de expansão
void Cube::CubeExpanding(int topLayer, int botLayer,int supEsq, int supDir, int infEsq, int infDir, int delayTime){
    if(supEsq < 64){
        digitalWrite(topLayer,HIGH); 
        digitalWrite(botLayer,HIGH);
        setRegisterPin(supDir,HIGH);
        setRegisterPin(supEsq,HIGH);
        setRegisterPin(infDir,HIGH);
        setRegisterPin(infEsq,HIGH);   
        writeRegister();

    for(int i = infDir; i < infEsq; i++){
        setRegisterPin(i,HIGH);  
    }

    for(int i = infEsq; i < supEsq;){
        setRegisterPin(i,HIGH);
        i = i + 8;       
    }

    for(int i = supDir; i < supEsq; i++){
        setRegisterPin(i,HIGH);  
    }

    for(int i = infDir; i < supDir;){
        setRegisterPin(i,HIGH);
        i = i + 8;       
    }

    writeRegister();         
    delay(delayTime);
    CubeExpanding(topLayer + 1, botLayer - 1, supEsq + 9, supDir + 7, infEsq - 7, infDir - 9, delayTime);     
}
}

void Cube::CubeShrinking(int topLayer, int botLayer,int supEsq, int supDir, int infEsq, int infDir, int delayTime){
    if(supEsq > 36){
        setRegisterPin(supDir,LOW);
        setRegisterPin(supEsq,LOW);
        setRegisterPin(infDir,LOW);
        setRegisterPin(infEsq,LOW);   
        writeRegister();

        for(int i = infDir; i < infEsq; i++){
            setRegisterPin(i,LOW);  
        }

        for(int i = infEsq; i < supEsq;){
            setRegisterPin(i,LOW);
            i = i + 8;       
        }

        for(int i = supDir; i < supEsq; i++){
            setRegisterPin(i,LOW);  
        }

        for(int i = infDir; i < supDir;){
            setRegisterPin(i,LOW);
            i = i + 8;       
        }

        writeRegister();   
        digitalWrite(botLayer, LOW);
        digitalWrite(topLayer, LOW);     
        delay(delayTime);
        CubeShrinking(topLayer - 1, botLayer + 1, supEsq - 9, supDir - 7, infEsq + 7, infDir + 9, delayTime);
    }
}

//Funções auxiliares da animação de scanner
void Cube::backToFront(int startingPoint){
    clearRegisters();
    writeRegister();
    lightAllLayers();
    if(startingPoint >= 0){  
        for(int i = startingPoint; i < startingPoint + 8; i++){
            setRegisterPin(i, HIGH);    
        }
        writeRegister();
        delay(100);
        backToFront(startingPoint - 8);
    }   
}

void Cube::frontToBack(int startingPoint){
    clearRegisters();
    writeRegister();
    lightAllLayers();
    if(startingPoint < 64){  
        for(int i = startingPoint; i < startingPoint + 8; i++){
            setRegisterPin(i, HIGH);    
        }
        writeRegister();
        delay(100);
        frontToBack(startingPoint + 8);
    }   
}

void Cube::rightToLeft(int startingPoint){
    clearRegisters();
    writeRegister();
    lightAllLayers();
    if(startingPoint >= 0){  
        for(int i = startingPoint; i < 64;){
            setRegisterPin(i, HIGH);
            i = i+8;    
        }
        writeRegister();
        delay(100);
        rightToLeft(startingPoint - 1);
    }
}

void Cube::leftToRight(int startingPoint){
    clearRegisters();
    writeRegister();
    lightAllLayers();
    if(startingPoint < 8){  
        for(int i = startingPoint; i < 64;){
            setRegisterPin(i, HIGH);
            i = i + 8;    
        }
        writeRegister();
        delay(100);
        leftToRight(startingPoint + 1);
    }   
}

void Cube::topToBot(){
    lightAllRegisters();
    writeRegister();

    for(int i = 8; i >= 1; i--){
        digitalWrite(layersArray[i], HIGH);
        digitalWrite(layersArray[i + 1], LOW);
        digitalWrite(layersArray[i - 1], LOW);        
        delay(100);
    }
    clearRegisters();
    writeRegister();
    clearLayers();
}

void Cube::botToTop(){
    lightAllRegisters();
    writeRegister();

    for(int i = 0; i <= 8 + 1; i++){
        digitalWrite(layersArray[i], HIGH);
        digitalWrite(layersArray[i + 1], LOW);
        digitalWrite(layersArray[i - 1], LOW);        
        delay(100);
    }
    clearRegisters();
    writeRegister();
    clearLayers();
}